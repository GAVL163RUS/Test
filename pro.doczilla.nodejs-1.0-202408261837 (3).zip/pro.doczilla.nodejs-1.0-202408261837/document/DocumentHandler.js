let domParser = require('../dom/DomParser').domParser;
const DatasetData = require("../data/DatasetData");
let VariableData = require('../data/VariableData');
let DictionaryData = require('../data/DictionaryData');
let {isEmptyObject} = require('../util/Util');
const StructureData = require("../data/StructureData");
const StructureInfo = require("../data/StructureInfo");

class DocumentHandler {

	constructor(config, docx) {
		this.config = config;
		this._document = this.readDocument(docx);
	}

	getExternalStructure() {
		let externalStructure = this.getConfig().getOptionStructure(); // структура мастер документа при заполнении поддокументов
		if(externalStructure == null)
			return null;

		let document = new DoczillaDocument();
		document.getStructurePart().read(domParser.parseFromString(externalStructure, 'application/xml').firstChild);
		return document.getStructure();
	}

	buildDocument(data) {
		let document = this.getDocument().lock();
		let config = this.getConfig();

		let externalStructure = this.getExternalStructure();
		let structure = externalStructure || this.getDocumentStructure();

		document.setStructure(structure.setDataMode(Structure.Questionnaire));

		let resetStructure = config.isResetStructure();
		if(resetStructure)
			structure.reset();

		let structureChanged = this.fillStructure(data, config);

		structure.getPart().setChanged(externalStructure == null && (structureChanged || resetStructure || structure.getIgnoreHidden()));
		structure.setIgnoreHidden(false).build();

		this.setFormatters(structure.getElements());

		document.update(structure.getElements());
		config.isPreserveAllFieldsMode() ? document.toModification(Date.Max, Date.Max) : document.toDocx(!this.getConfig().isClearHiddenFieldsMode());
		document.updateFields();
		document.pastePermissions(data != null ? data.permissions : null);

		if(config.getDocumentType() != null)
			document.setType(config.getDocumentType());

		for(var part of document.getTitleParts())
			part.setChanged(true);

		document.getBodyPart().setChanged(true);
	}

	setFormatters(elements) {
		// set elements empty value format
		let emptyFormatFn = this.getEmptyValueFormatFn();
		if(typeof emptyFormatFn != 'function')
			return;

		for(let element of elements)
			if(element.isVariable())
				element.setEmptyValueFormatFn(emptyFormatFn);
	}

	getEmptyValueFormatFn() {
		let format = this.getConfig().getEmptyValueFormatterOption();
		if(format != null) {
			return function() {
				return format[this.getTypeName()] || this.getName(); // with element context
			};
		}
		return null;
	}

	fillStructure(parsedData, config) {
		let changed = false;
		let structure = this.getDocumentStructure();
		structure.setIgnoreHidden(false).build();

		// TODO getOptionData уже не актуально?
		if(isEmptyObject(parsedData)) {
			parsedData = config.getOptionData();
			if(parsedData != null)
				changed = new VariableData(structure).fillStructure(parsedData);
		} else {
			let datasetData = parsedData['dataset'];

			if(isEmptyObject(datasetData))
				changed = new VariableData(structure).fillStructure(parsedData['data']);
			else
				changed = new DatasetData(structure).fillStructure(datasetData, parsedData['dataById']);

			let dataSources = structure.getDataSources();
			for(let dictionaryDataWrap of parsedData['dictionaryData'] || []) {
				let dictionaryData = new DictionaryData(structure, dictionaryDataWrap['dictionaryClass'], dataSources);
				changed |= dictionaryData.fillStructure(dictionaryDataWrap['data']);
			}
		}
		return changed;
	}

	extractStructureInfo() {
		let document = this.getDocument().lock();

		let structure = document.getStructure();
		structure.setIgnoreHidden(false).build();

		const structureInfo = new StructureInfo(structure);
		return {
			dataSources: structureInfo.extractDataSources(),
			scheme: structureInfo.extractStructure()
		};
	}

	extractStructureData(data) {
		let document = this.getDocument().lock();
		let structure = document.getStructure();
		// заполнение вызывает build структуры
		this.fillStructure(data, this.getConfig());

		let elements = structure.getElements();
		this.setFormatters(elements);

		const structureData = new StructureData(structure);

		return {
			dataSources: structureData.extractDataSources(),
			scheme: structureData.extractStructure(),
			permissions: this.extractPermissions()
		};
	}

	extractStructure(data) {
		let document = this.getDocument().lock();

		let structure = document.getStructure();
		let dataSources = structure.getDataSources();
		let result = {};

		// заполнение вызывает build структуры
		this.fillStructure(data, this.getConfig());

		let elements = structure.getElements();
		this.setFormatters(elements);

		// dataById: {varId: varValue, ...}
		// data: {varIdentifier: varValue, ...}
		let variableData = new VariableData(structure).extractStructure();
		result.dataById = variableData.dataById;
		result.data = variableData.data;

		// dataset: {rows: [variants: []... ], ...}
		result.dataset = new DatasetData(structure).extractStructure();

		// read dataSource classes
		let dataSourceClasses = [];
		for(let dataSource of dataSources) {
			let dsClass = dataSource.getServerId();
			if(!dataSourceClasses.contains(dsClass))
				dataSourceClasses.push(dsClass);
		}
		// dictionaryData: [..., {'dictionaryClass': dsClass, 'data': {varColumn: varValue...}}, ...]
		result.dictionaryData = [];
		for(let dataSourceClass of dataSourceClasses)
			result.dictionaryData.push(new DictionaryData(structure, dataSourceClass, dataSources).extractStructure());

		// read permissions
		result.permissions = this.extractPermissions();

		return result;
	}

	extractPermissions() {
		return this.getDocument().lock().copyPermissions();
	}

	extractText() {
		var story = this.getStory();
		var target = story.getTargetState().setStart(0);
		var withNumbers = this.getConfig().getWithNumbers();
		var text = '';

		for(var paragraph of story) {
			if(!paragraph.getVisible())
				continue;

			target = target.setFirstParagraph(paragraph).collapseToStart().expandToParagraphs().offsetEnd(-1);

			var paragraphText = target.getVisibleText();
			var number = withNumbers ? paragraph.getNumber() : null;

			text += (number == null ? '' : number + ' ') + (paragraphText == null ? '' : paragraphText) + '\n';
		}

		return text;
	}

	validate(data) {
		let structure = this.getDocumentStructure();

		// заполнение вызывает build структуры
		this.fillStructure(data, this.getConfig());

		let result = {}
		result.validation = new VariableData(structure).validateStructure();
		return result;
	}

	readDocument(docx) {
		return new DoczillaDocument().readXml(docx, domParser);
	}

	writeDocument() {
		return this.getDocument().writeXml(Mime.Binary, this.getConfig().getWriteOptions());
	}

	getConfig() {
		return this.config;
	}

	isTemplateDocument() {
		return this.getDocument().getType() === Document.Template;
	}

	isDoczDocument() {
		return !this.isTemplateDocument();
	}

	getDocument() {
		return this._document;
	}

	getStory() {
		return this.getDocument().getStory();
	}

	getDocumentStructure() {
		return this.getDocument().getStructure();
	}
}

module.exports = DocumentHandler