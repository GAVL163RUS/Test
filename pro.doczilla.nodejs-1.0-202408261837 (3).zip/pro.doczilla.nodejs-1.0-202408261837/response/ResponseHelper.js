const successResponse = function (data) {
	return _createResponse(true, data);
}

const errorResponse = function (error, data) {
	return _createResponse(false, _createErrorPayload(error, data));
}

function _createResponse(success, data) {
	return {
		success: success,
		payload: data
	}
}

function _createErrorPayload(error, data) {
	let errorObj = {};

	if(typeof error === 'object') {
		const {name, message, status, stack} = error;
		Object.assign(errorObj, {status, name, message, stack});
	} else
		Object.assign(errorObj, {message: error});

	return Object.assign({error: errorObj}, data);
}

module.exports = {
	successResponse,
	errorResponse
}