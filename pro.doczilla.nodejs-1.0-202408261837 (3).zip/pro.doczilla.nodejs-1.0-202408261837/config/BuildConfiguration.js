const _parameters = {
	MODE: 'templateMode',
	TYPE: 'documentType',
	RESET_STRUCTURE: 'resetStructure',
	OPTIONS: 'options'
};

const _templateModes = {
	PreserveAllFields: 'PreserveAllFields',
	PreserveNoValueFields: 'PreserveNoValueFields',
	ClearAllFields: 'ClearAllFields',
	ClearVanishFields: 'ClearVanishFields'
};

const _options = {
	EmptyValueFormatter: 'emptyValueFormatter',
	Data: 'data',
	Structure: 'structure',
	WithNumbers: 'withNumbers'
}

class BuildConfiguration {

	constructor(config) {
		const configuration = this._configuration = config != null ? JSON.parse(config) : {};

		let param = configuration[_parameters.MODE];
		this._mode = (param || _templateModes.ClearAllFields).trim();

		this._resetStructure = configuration[_parameters.RESET_STRUCTURE] === true;

		param = configuration[_parameters.TYPE];
		if(param != null)
			this._documentType = param === 'Template' ? Mime.Template : Mime.Document;

		param = configuration[_parameters.OPTIONS] || {};
		this._options = typeof param == 'string' ? JSON.parse(param) : param;
	}

	static getParameters() {
		return _parameters;
	}

	static getTemplateModes() {
		return _templateModes;
	}

	getMode() {
		return this._mode;
	}

	getDocumentType() {
		return this._documentType;
	}

	getOptions() {
		return this._options;
	}

	getOption(name) {
		return this._options != null ? this._options[name] : null;
	}

	getEmptyValueFormatterOption() {
		return this.getOption(_options.EmptyValueFormatter);
	}

	getOptionData() {
		return this.getOption(_options.Data);
	}

	getOptionStructure() {
		return this.getOption(_options.Structure);
	}

	getWithNumbers() {
		return this.getOption(_options.WithNumbers);
	}

	getConfiguration() {
		return this._configuration;
	}

	isResetStructure() {
		return this._resetStructure;
	}

	isPreserveAllFieldsMode() {
		return this.getMode() === _templateModes.PreserveAllFields;
	}

	isPreserveNoValueFieldsMode() {
		return this.getMode() === _templateModes.PreserveNoValueFields;
	}

	isClearAllFieldsMode() {
		return this.getMode() === _templateModes.ClearAllFields;
	}

	isClearHiddenFieldsMode() {
		return this.getMode() === _templateModes.ClearVanishFields;
	}

	isTemplateTargetDocument() {
		return this.getDocumentType() === Document.Template;
	}

	isDoczTargetDocument() {
		return !this.isTemplateTargetDocument();
	}

	getWriteOptions() {
		if (this.isClearAllFieldsMode())
			return new DocxWriteOptions().setPermissions(false);

		return null;
	}
}

module.exports = BuildConfiguration