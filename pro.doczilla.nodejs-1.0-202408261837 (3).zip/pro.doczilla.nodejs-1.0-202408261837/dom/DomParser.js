
var {JSDOM} = require('jsdom');
var dom = new JSDOM(''); // TODO elements querySelector not work without namespace prefix

var DomParserClass = dom.window.DOMParser;
var domParser = new dom.window.DOMParser();

module.exports = {
	DomParserClass,
	domParser
}