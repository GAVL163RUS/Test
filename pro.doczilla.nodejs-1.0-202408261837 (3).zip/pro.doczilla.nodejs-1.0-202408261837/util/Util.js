function atob(str) {
	return Buffer.from(str, 'base64').toString('binary');
}

function btoa(str) {
	let buffer;
	if (str instanceof Buffer)
		buffer = str;
	else
		buffer = Buffer.from(str.toString(), 'binary');

	return buffer.toString('base64');
}

function isEmptyObject(obj) {
	return obj == null || obj && Object.keys(obj).length === 0 && obj.constructor === Object;
}

module.exports = {
	atob, btoa, isEmptyObject
}