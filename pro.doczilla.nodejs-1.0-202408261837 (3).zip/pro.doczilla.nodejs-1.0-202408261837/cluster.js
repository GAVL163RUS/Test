var cluster = require('cluster');
var os = require('os');

cluster.setupMaster({exec: __dirname + '/server.js'});

for (var i = 0; i < os.cpus().length; i++) {
    cluster.fork();
}

cluster.on('exit', function(worker, code, signal) {
    console.log('Server process ' + worker.process.pid + ' died');
});
