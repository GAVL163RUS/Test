let VariableData = require('./VariableData');

// TODO переработать!!!
class DictionaryData extends VariableData {

	constructor(structure, dictionaryClass, dataSources) {
		super(structure);

		this.dictionaryClass = dictionaryClass;
		this.dataSourceIds = [];
		for(let source of dataSources)
			if(source.getServerId() == dictionaryClass)
				this.dataSourceIds.push(source.getId());

		// {dictColumnName: [varId1, varId2,...]}
		this.keyIdsMap = {};
		// {varId: dictColumnName}
		this.idKeyMap = {};
		this.createElementsMap(this.structure.getScheme());
	}

	// TODO refactor
	createElementsMap(elements) {
		for(let element of elements) {
			let boundField = element.getBoundDataField();
			let dataSource = element.getDataSource();

			if(boundField != null && this.dataSourceIds.includes(dataSource.getId())) {
				const fieldId = boundField.getServerId();

				let boundElements = this.keyIdsMap[fieldId] || [];

				boundElements.push(element.getId());

				this.keyIdsMap[fieldId] = boundElements;
				this.idKeyMap[element.getId()] = fieldId;
			}

			if(!element.isEmpty())
				this.createElementsMap(element);
		}
	}

	fillStructure(data) {
		let changed = false;
		if(data == null)
			return changed;

		for(const [key, value] of Object.entries(data)) {
			let variableIds = this.keyIdsMap[key] || [];
			for(let varId of variableIds) {
				let element = this.structure.getElement(varId);
				element.setValue(this.parseValue(element, value));
				changed = true;
			}
		}
		return changed;
	}

	/**
	 * Возвращает заполненные данные для заданного класса справочника dictionaryClass
	 * @returns {{data: *[], dictionaryClass}}
	 */
	extractStructure() {
		const dataArray = [];
		let structure = this.structure;

		for(let dataSourceId of this.dataSourceIds) {
			let data = {}; // данные переменных без мультипликаторов
			let dataSourceAssigned = false;
			let dataHasNotHidden = false;

			let replicatorsDataBuffer = {}; // буфер для значений реплик всех мультипликаторов

			let dataSourceValue = null;

			let boundElements = DataSourceManager.getDataSourceBoundElements(structure, dataSourceId, true);

			for(let element of boundElements) {
				let field = element.getBoundDataField();

				let column = field.getServerId();

				let replicator = element.getReplicator();

				if(replicator == null) {
					if(!dataSourceAssigned) {
						dataSourceAssigned = true;
						dataSourceValue = this.getDataSourceData(element);
						if(dataSourceValue != null)
							Object.assign(data, dataSourceValue);
					}
					if(element.isHidden()) {
						data[column] = undefined;
					} else {
						data[column] = element.getValue();
						dataHasNotHidden = true;
					}

				} else {
					let replicatorDataArray = replicatorsDataBuffer[replicator.getId()];
					if(replicatorDataArray == null) {
						replicatorDataArray = [];
						replicatorsDataBuffer[replicator.getId()] = replicatorDataArray;
					}

					let replicatorValue = replicator.getValue();

					for(let position = 0; position < replicatorValue.getCount(); position++) {
						let replicaData = replicatorDataArray[position];
						if(replicaData == null) {
							replicaData = {dataSourceAssigned: false, dataHasNotHidden: false, data: {}};
							replicatorDataArray[position] = replicaData;
						}

						if(!replicaData.dataSourceAssigned) {
							replicaData.dataSourceAssigned = true;
							dataSourceValue = this.getDataSourceData(element, position);
							if(dataSourceValue != null)
								Object.assign(replicaData.data, dataSourceValue);
						}

						if(element.isHidden()) {
							replicaData.data[column] = undefined;
						} else {
							replicaData.data[column] = element.getValue(position);
							replicaData.dataHasNotHidden = true;
						}
					}
				}
			}

			if(dataHasNotHidden)
				dataArray.push(data);

			for(let replicatorArray of Object.values(replicatorsDataBuffer))
				for(let replicatorData of replicatorArray)
					if(replicatorData.dataHasNotHidden)
						dataArray.push(replicatorData.data);

		}

		return {'dictionaryClass': this.dictionaryClass, 'data': dataArray};
	}

	parseDataset(replicator, value) {
		let rows = [];
		// dataItem: {dictColumnName: value, ...} or {varId: value, ...}
		for(let dataItem of value || []) {
			let row = new DatasetRow();
			for(const [dataId, dataValue] of Object.entries(dataItem)) {
				// check dictColumnName
				let varIds = this.keyIdsMap[dataId];
				if(varIds != null && varIds.length) {
					for(let varId of varIds)
						this.setDatasetRowValue(replicator, row, varId, dataValue);

				} else {
					// check varId
					let columnName = this.idKeyMap[dataId];
					if(columnName != null)
						this.setDatasetRowValue(replicator, row, dataId, dataValue);
				}
			}
			rows.add(row);
		}

		// TODO fill one row from multiple dictionaries
		return new Dataset(rows);
	}
}

module.exports = DictionaryData