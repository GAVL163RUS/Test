const {isEmptyObject} = require("../util/Util");
const VariableData = require("./VariableData");

// TODO refactoring
class DatasetData extends VariableData {

	constructor(structure) {
		super(structure);
	}

	fillStructure(data, dataById) {
		if(isEmptyObject(data))
			return false;

		let structure = this.structure;
		let dataset = this.parseDataset(data);

		// Необходимо для переноса данных со старых анкет
		// если в dataset нет значения переменной, то заполняем её из dataById
		if(!isEmptyObject(dataById)) {
			for(const [id, value] of Object.entries(dataById)) {
				let element = structure.getElement(id);
				if(element == null || element.isReplicator() || element.isDataSource())
					continue;

				let parsedValue = this.parseValue(element, value);
				let isEmptyValue = parsedValue == null || String.isString(parsedValue) && parsedValue.isEmpty() || Number.isNumber(parsedValue) && !Number.isDefined(parsedValue);

				let elementValue = dataset.get(element);
				if(elementValue == null && !isEmptyValue)
					dataset.set(element, parsedValue);
			}
		}

		structure.dataset = dataset;

		return true;
	}

	extractStructure() {
		return this.structure.getDataset();
	}

	parseDataset(json) {
		let parseDataset = (obj) => {
			let dataset = new Dataset();
			let rows = [];

			for(let row of obj.rows)
				rows.push(parseDatasetRow(row));

			if(obj.position != null)
				dataset.setPosition(obj.position);

			return dataset.setRows(rows);
		}

		let parseDatasetRow = (obj) => {
			let values = {};

			if(obj.variants != null)
				for(const [id, variant] of Object.entries(obj.variants)) {
					values[id] = parseVariant(variant);
				}

			return new DatasetRow(values);
		}

		let parseVariant = (obj) => {
			let variant;

			for(const [type, value] of Object.entries(obj)) {
				switch(type) {
					case 'boolean':
						(variant || (variant = new Variant())).setBoolean(value);
						break;
					case 'dataset':
						(variant || (variant = new Variant())).setDataset(parseDataset(value));
						break;
					case 'date':
						(variant || (variant = new Variant())).setDate(value != null ? Parser.datetime(value) : null);
						break;
					case 'number':
						(variant || (variant = new Variant())).setNumber(value != null ? parseFloat(value) : null);
						break;
					case 'unit':
						(variant || (variant = new Variant())).setUnit(value);
						break;
					case 'string':
						(variant || (variant = new Variant())).setString(value);
						break;
					case 'image':
						(variant || (variant = new Variant())).setImage(value);
						break;
				}
			}
			return variant;
		}

		return parseDataset(json);
	}

}

module.exports = DatasetData;