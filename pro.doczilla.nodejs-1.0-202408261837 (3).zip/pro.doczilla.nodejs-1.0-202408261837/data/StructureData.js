const StructureInfo = require("./StructureInfo");

/**
 * Класс для работы с данными структуры.
 */
class StructureData extends StructureInfo {
	constructor(structure) {
		super(structure);
	}

	/**
	 * Заполнение структуры данными из json
	 * @param data json
	 * @returns {boolean}
	 */
	fillStructure(data) {
		let changed = false;
		if(data == null)
			return changed;

		for(const [key, value] of Object.entries(data)) {
			let element = this.getElementByIdentifierOrId(key); // TODO нужно ли искать по ID?

			if(element == null || element.isSelector()) // TODO fill selectors?
				continue;

			// если radio, то отключаем остальные ответы
			if(element.isRadioOption() && !!value)
				for(var option = element.getParent().getFirst(); option != null; option = option.getNext())
					option.setValue(option == element);
			else
				element.setValue(this.parseValue(element, value));

			changed = true;
		}
		return changed;
	}

	extractStructure() {
		const structureData = {};
		for(let element of this.getStructure().getScheme()) {
			if(element.isReplicator())
				this.extractReplicatorElementData(structureData, element, null);
			else
				this.extractElementData(structureData, element, null);
		}
		return structureData;
	}

	extractElementData(data, element, path) {
		const value = element.getValue(path);

		const elementData = this.collectElementData(element, value, path);

		this.extractElementDataSourceData(data, element, path);

		if(element.getCount()) {
			const elements = {};
			for (let childElement of element)
				if (childElement.isReplicator())
					this.extractReplicatorElementData(elements, childElement, path);
				else
					this.extractElementData(elements, childElement, path);

			elementData.elements = elements;
		}

		data[element.getIdentifier()] = elementData;
	}

	extractReplicatorElementData(data, element, path) {
		const value = element.getValue(path);

		const replicatorData = this.collectReplicatorElementData(element, value, path);

		const replicatorValues = [];
		if(value != null) {
			for (let position = 0; position < value.getCount(); position++) {
				const replicaValues = {};
				for (let replicatorElement of element) {
					if (replicatorElement.isReplicator())
						this.extractReplicatorElementData(replicaValues, replicatorElement, position);
					else
						this.extractElementData(replicaValues, replicatorElement, position);
				}
				replicatorValues.add(replicaValues);
			}
		}

		replicatorData.elements = replicatorValues;

		data[element.getIdentifier()] = replicatorData;
	}

	extractElementDataSourceData(data, element, path) {
		var dataSource = element.getDataSource();
		if(dataSource == null || data[dataSource.getIdentifier()] != null)
			return;

		var dataSourceValue = element.getDataSourceValue(path);
		if(dataSourceValue == null)
			return null;

		var dataSourceFieldsData = {};
		for(var field of dataSource)
			dataSourceFieldsData[field.getServerId()] = Object.assign(this.constructor.getDataSourceElementInfo(field), {value: dataSourceValue.get(field)});

		data[dataSource.getIdentifier()] = Object.assign(this.constructor.getDataSourceElementInfo(dataSource), {position: path, elements: dataSourceFieldsData});
	}

	collectElementData(element, value, path) {
		return Object.assign(
			this.collectElementInfo(element),
			this.constructor.getElementValidationInfo(element, value),
			this.constructor.getElementValueInfo(element, value, path)
		);
	}

	collectReplicatorElementData(element, value, path) {
		return Object.assign(
			this.collectReplicatorElementInfo(element),
			this.constructor.getElementValidationInfo(element, value),
			this.constructor.getElementValueInfo(element, value, path)
		);
	}

	static getElementValidationInfo(element, value) {
		let validate = Validator.validate(value, element);
		let isValid = validate == null;
		const info =  {
			filled: Validator.isFilled(value, element),
			valid: Boolean(isValid)
		};

		if(!isValid)
			info.validationError = validate;

		return info;
	};

	static getElementValueInfo(element, value, position) {
		const info = {
			visible: element.isVisible(position),
			hidden: element.isHidden(position)
		}
		if(position != null)
			info.position = position;

		if(!element.isReplicator() && !element.isSelector())
			info.value = value;

		return info;
	}

	getElementByIdentifierOrId(id) {
		const structure = this.getStructure();
		let element = structure.getByIdentifier(id);
		return element != null ? element : structure.getElement(id);
	}

	parseValue(element, value) {
		switch (element.getTypeName()) {
			case ElementType.Boolean:
				return this.parseBoolean(element, value);
			case ElementType.Percent:
				return this.parsePercent(element, value);
			case ElementType.Number:
				return this.parseNumber(element, value);
			case ElementType.Money:
				return this.parseMoney(element, value);
			case ElementType.Date:
				return this.parseDate(element, value);
			case ElementType.Dataset:
				return this.parseDataset(element, value);
			case ElementType.DataSource:
				return this.parseDataSource(element, value);
			case ElementType.String:
			default:
				return this.parseString(element, value);
		}
	}

	parseBoolean(element, value) {
		return value != null ? value == '1' || value == 'true' : null;
	}

	parseNumber(element, value) {
		if (value == null)
			return null;
		var parsed = parseFloat(value);
		return Number.isDefined(parsed) ? parsed : null;
	}

	parsePercent(element, value) {
		return this.parseNumber(element, value);
	}

	parseMoney(element, value) {
		return this.parseNumber(element, value);
	}

	parseDate(element, value) {
		return value != null ? Parser.datetime(value) : null;
	}

	parseDataSource(dataSource, value) {
		var datasetRow = new DatasetRow(DataSourceManager.parseVariants(dataSource, value));
		return new Dataset([datasetRow]);
	}

	parseDataset(replicator, value) {
		let rows = [];
		// dataItem: {varId: value, ...}
		for(let dataItem of value || []) {
			let row = new DatasetRow();
			for(const [dataId, dataValue] of Object.entries(dataItem))
				this.setDatasetRowValue(replicator, row, dataId, dataValue);
			rows.add(row);
		}

		// если нет реплик, то добавляем пустую
		if(rows.length == 0)
			rows.add(new DatasetRow());

		return new Dataset(rows);
	}

	setDatasetRowValue(replicator, row, variableId, value) {
		let element = this.getElementByIdentifierOrId(variableId);
		if(element != null && element.getReplicator() == replicator && !element.isExpression() && !element.isSelector())
			row.set(element, this.parseValue(element, value));
	}

	parseString(element, value) {
		return value != null ? String(value) : '';
	}
}

module.exports = StructureData;