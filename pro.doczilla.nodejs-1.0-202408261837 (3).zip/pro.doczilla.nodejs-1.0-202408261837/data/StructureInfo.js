/**
 * Класс для работы с данными структуры.
 */
class StructureInfo {
	constructor(structure) {
		this.structure = structure;
	}

	getStructure() {
		return this.structure;
	}

	extractStructure() {
		const structureData = {};
		for(let element of this.getStructure().getScheme()) {
			if(element.isReplicator())
				this.extractReplicatorElementData(structureData, element, null);
			else
				this.extractElementData(structureData, element, null);
		}
		return structureData;
	}

	extractDataSources() {
		const dataSourcesData = {};
		for(let dataSource of this.getStructure().getDataSources())
			this.extractDataSourceInfo(dataSourcesData, dataSource);
		return dataSourcesData;
	}

	extractElementData(data, element, path) {
		const elementData = this.collectElementInfo(element);

		if(element.getCount()) {
			const elements = {};
			for (let childElement of element)
				if (childElement.isReplicator())
					this.extractReplicatorElementData(elements, childElement, path);
				else
					this.extractElementData(elements, childElement, path);

			elementData.elements = elements;
		}

		data[element.getIdentifier()] = elementData;
	}

	extractReplicatorElementData(data, element) {
		const replicatorData = this.collectReplicatorElementInfo(element);

		const replicatorElements = {};
		for (let replicatorElement of element) {
			if (replicatorElement.isReplicator())
				this.extractReplicatorElementData(replicatorElements, replicatorElement);
			else
				this.extractElementData(replicatorElements, replicatorElement);
		}

		replicatorData.elements = replicatorElements;

		data[element.getIdentifier()] = replicatorData;
	}

	extractDataSourceInfo(data, dataSource) {
		const dataSourceInfo = this.constructor.getDataSourceElementInfo(dataSource);

		if(dataSource.getCount()) {
			const fields = {};
			for (let field of dataSource)
				this.extractDataSourceInfo(fields, field);

			dataSourceInfo.elements = fields;
		}

		data[dataSource.getIdentifier()] = dataSourceInfo;
	}

	collectElementInfo(element) {
		return Object.assign(
			this.constructor.getElementInfo(element),
			this.constructor.getElementDataSourceInfo(element)
		);
	}

	collectReplicatorElementInfo(element) {
		return Object.assign(
			this.constructor.getElementInfo(element),
			this.constructor.getElementDataSourceInfo(element)
		);
	}

	static getElementInfo(element) {
		const parent = element.getParent();

		const info = {
			index: element.getIndex(),
			id: element.getId(),
			identifier: element.getIdentifier(),
			guid: element.getGuid(),
			name: element.getName(),
			kind: element.getKind(),
			required: element.getRequired(),
			parentId:  element.getParentId(),
			parentIdentifier:  parent != null ? parent.getIdentifier() : null,
			valueMode: element.getValueMode()
		};

		if(element.isExpression())
			info.expression = element.getExpression();

		if(element.isSelector())
			info.selectorType = element.getSelectorType();

		if(element.isVariable() || element.isCondition())
			info.type = element.getTypeName();

		return info;
	};

	static getDataSourceElementInfo(element) {
		const info = {
			index: element.getIndex(),
			id: element.getId(),
			identifier: element.getIdentifier(),
			guid: element.getGuid(),
			name: element.getName(),
			kind: element.getKind(),
			valueMode: element.getValueMode(),
			serverId: element.getServerId()
		};

		if(element.isDataSource())
			info.serverName = element.getServerName();

		if(element.isDataField())
			info.serverType = element.getServerType();

		return info;
	};

	static getElementDataSourceInfo(element) {
		const dataSource = element.getDataSource();
		if(dataSource == null)
			return {};

		// TODO нужно ли все поля писать?
		const info = {
			dataSourceIdentifier: dataSource.getIdentifier(),
			// dataSourceId: dataSource.getId(),
			// dataSourceServerId: dataSource.getServerId()
		};

		const boundDataField = element.getBoundDataField();
		info.dataFieldIdentifier = boundDataField.getIdentifier();
		// info.dataFieldId = boundDataField.getId();
		// info.dataFieldServerId = boundDataField.getServerId();

		return info;
	}
}

module.exports = StructureInfo;