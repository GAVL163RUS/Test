const {isEmptyObject} = require("../util/Util");
const StructureData = require("./StructureData");

class VariableData extends StructureData {
	constructor(structure) {
		super(structure);
	}

	/**
	 * Возвращает json с данными:
	 * 		dataById - значения всех переменных и источников по ID
	 * 		data - значения видимых переменных (visible) по идентификаторам
	 * @returns {{data: {}, dataById: {}}}
	 */
	extractStructure() {
		var dataByIdentifier = {};
		var dataById = {};

		for(var element of this.structure.getScheme()) {
			if(element.isReplicator())
				this.extractReplicatorElementValue(dataById, dataByIdentifier, element, null);
			else
				this.extractElementValue(dataById, dataByIdentifier, element, null);
		}

		return {data: dataByIdentifier, dataById: dataById};
	}

	extractReplicatorElementValue(dataById, dataByIdentifier, element, path) {
		var id = element.getId();
		var identifier = element.getIdentifier();
		var value = element.getValue(path);

		if(value == null)
			return;

		var idRows = [];
		var identifierRows = [];

		for(var position = 0; position < value.getCount(); position++) {
			var rowIdValue = {};
			var rowIdentifierValue = {};

			for(var replicatorElement of element)
				if (replicatorElement.isReplicator())
					this.extractReplicatorElementValue(rowIdValue, rowIdentifierValue, replicatorElement, position);
				else
					this.extractElementValue(rowIdValue, rowIdentifierValue, replicatorElement, position);

			if(!isEmptyObject(rowIdValue))
				idRows.push(rowIdValue);
			if(!isEmptyObject(rowIdentifierValue))
				identifierRows.push(rowIdentifierValue);
		}

		if(idRows.length) {
			dataById[id] = idRows;
			if(identifier != null && identifierRows.length)
				dataByIdentifier[identifier] = identifierRows;
		}
	}

	extractElementValue(dataById, dataByIdentifier, element, path) {
		var id = element.getId();
		var identifier = element.getIdentifier();
		var value = element.getValue(path);

		var dataSource = element.getDataSource();
		if(dataSource != null) {
			var dataSourceId = dataSource.getId();
			if(dataById[dataSourceId] == null)
				dataById[dataSourceId] = this.getDataSourceDataById(element, path);

			var dataSourceIdentifier = dataSource.getIdentifier();
			if(dataSourceIdentifier != null && element.isVisible(path) && dataByIdentifier[dataSourceIdentifier] == null)
				dataByIdentifier[dataSourceIdentifier] = this.getDataSourceData(element, path);
		}

		if (element.isVariable() || element.isCondition()) {
			dataById[id] = value;
			if(identifier != null && element.isVisible(path))
				dataByIdentifier[identifier] = value;
		}

		for (var childElement of element)
			if (childElement.isReplicator())
				this.extractReplicatorElementValue(dataById, dataByIdentifier, childElement, path);
			else
				this.extractElementValue(dataById, dataByIdentifier, childElement, path);
	}

	/**
	 * Проверка переменных на заполнение и корректность заполнения
	 * @return {{variables: *[], statistic: {allFilled: boolean, allRequiredFilled: boolean}}}
	 */
	validateStructure() {
		var variables = [];

		for(var element of this.structure.getScheme()) {
			if(element.isReplicator())
				this.validateReplicatorElement(variables, element, null);
			else
				this.validateElement(variables, element, null);
		}

		var hasElements = function(elements, hasFn) {
			if(elements == null)
				return false;

			var has = false;
			for(var element of elements) {
				if(element.type == ElementType.Dataset)
					has = has || hasElements(element.elements, hasFn);
				else
					has = has || hasFn(element);
			}

			return has;
		}

		return {
			variables: variables,
			statistic: {
				allFilled: Boolean(!hasElements(variables, function (element) { return !(!element.visible || element.filled && element.valid); })),
				allRequiredFilled: Boolean(!hasElements(variables, function (element) { return !(!element.visible || !element.required || element.filled && element.valid); }))
			}
		};
	}

	validateReplicatorElement(variables, element, path) {
		var value = element.getValue(path);
		var replicatorInfo = VariableData.getElementValidationInfo(element, value, path);
		var replicatorValues = [];

		if(value != null) {
			for (var position = 0; position < value.getCount(); position++) {
				var replicaValues = [];
				for (var replicatorElement of element) {
					if (replicatorElement.isReplicator())
						this.validateReplicatorElement(replicaValues, replicatorElement, position);
					else
						this.validateElement(replicaValues, replicatorElement, position);
				}
				replicatorValues.push(replicaValues);
			}
		}

		replicatorInfo.elements = replicatorValues;
		variables.push(replicatorInfo);
	}

	validateElement(variables, element, path) {
		var value = element.getValue(path);
		var elementInfo = VariableData.getElementValidationInfo(element, value, path);

		variables.add(elementInfo);

		for (var childElement of element)
			if (childElement.isReplicator())
				this.validateReplicatorElement(variables, childElement, path);
			else
				this.validateElement(variables, childElement, path);
	}

	static getElementInfo(element) {
		var info = {
			id: element.getId(),
			identifier: element.getIdentifier(),
			guid: element.getGuid(),
			name: element.getName(),
			kind: element.getKind(),
			required: element.getRequired(),
			parentId:  element.getParentId(),
			valueMode: element.getValueMode()
		};

		if(element.isSelector())
			info.selectorType = element.getSelectorType();

		if(element.isVariable() || element.isCondition())
			info.type = element.getTypeName();

		return info;
	};

	static getElementValidationInfo(element, value, position) {
		var info = VariableData.getElementInfo(element);

		let dataSource = element.getDataSource();
		if(dataSource != null) {
			info.dataSourceId = dataSource.getId();
			info.dataSourceIdentifier = dataSource.getIdentifier();
			info.dataSourceServerId = dataSource.getServerId();

			var boundDataField = element.getBoundDataField();
			info.dataFieldId = boundDataField.getId();
			info.dataFieldIdentifier = boundDataField.getIdentifier();
			info.dataFieldServerId = boundDataField.getServerId();
		}

		if(position != null)
			info.position = position;

		info.visible = element.isVisible(position);
		info.hidden = element.isHidden(position);
		info.filled = Validator.isFilled(value, element);

		if(!element.isReplicator())
			info.value = value;

		var validate = Validator.validate(value, element);
		var isValid = validate == null;
		info.valid = Boolean(isValid);
		if(!isValid)
			info.validationError = validate;

		return info;
	};

	getDataSourceDataById(element, path) {
		var dataSource = element.getDataSource();
		if(dataSource == null)
			return null;

		var dataSourceValue = element.getDataSourceValue(path);
		if(dataSourceValue == null)
			return null;

		var data = {};
		for(var field of dataSource)
			data[field.getId()] = dataSourceValue.get(field);

		return data;
	}

	getDataSourceData(element, path) {
		var dataSource = element.getDataSource();
		if(dataSource == null)
			return null;

		var dataSourceValue = element.getDataSourceValue(path);
		if(dataSourceValue == null)
			return null;

		var data = {};
		for(var field of dataSource)
			data[field.getServerId()] = dataSourceValue.get(field);

		return data;
	}

	getElementByIdentifierOrId(id) {
		const structure = this.structure;
		let element = structure.getByIdentifier(id);
		return element != null ? element : structure.getElement(id);
	}

	parseValue(element, value) {
		switch (element.getTypeName()) {
			case ElementType.Boolean:
				return this.parseBoolean(element, value);
			case ElementType.Percent:
				return this.parsePercent(element, value);
			case ElementType.Number:
				return this.parseNumber(element, value);
			case ElementType.Money:
				return this.parseMoney(element, value);
			case ElementType.Date:
				return this.parseDate(element, value);
			case ElementType.Dataset:
				return this.parseDataset(element, value);
			case ElementType.DataSource:
				return this.parseDataSource(element, value);
			case ElementType.String:
			default:
				return this.parseString(element, value);
		}
	}

	parseBoolean(element, value) {
		return value != null ? value == '1' || value == 'true' : null;
	}

	parseNumber(element, value) {
		if (value == null)
			return null;
		var parsed = parseFloat(value);
		return Number.isDefined(parsed) ? parsed : null;
	}

	parsePercent(element, value) {
		return this.parseNumber(element, value);
	}

	parseMoney(element, value) {
		return this.parseNumber(element, value);
	}

	parseDate(element, value) {
		return value != null ? Parser.datetime(value) : null;
	}

	parseDataSource(dataSource, value) {
		var datasetRow = new DatasetRow(DataSourceManager.parseVariants(dataSource, value));
		return new Dataset([datasetRow]);
	}

	parseDataset(replicator, value) {
		let rows = [];
		// dataItem: {varId: value, ...}
		for(let dataItem of value || []) {
			let row = new DatasetRow();
			for(const [dataId, dataValue] of Object.entries(dataItem))
				this.setDatasetRowValue(replicator, row, dataId, dataValue);
			rows.add(row);
		}

		// если нет реплик, то добавляем пустую
		if(rows.length == 0)
			rows.add(new DatasetRow());

		return new Dataset(rows);
	}

	setDatasetRowValue(replicator, row, variableId, value) {
		let element = this.getElementByIdentifierOrId(variableId);
		if(element != null && element.getReplicator() == replicator && !element.isExpression() && !element.isSelector())
			row.set(element, this.parseValue(element, value));
	}

	parseString(element, value) {
		return value != null ? String(value) : '';
	}
}

module.exports = VariableData;